/*
 *  Do not modify this file; it is automatically 
 *  generated and any modifications will be overwritten.
 *
 * @(#) xdc-z52
 */

#ifndef sylink_test__
#define sylink_test__



#endif /* sylink_test__ */ 
